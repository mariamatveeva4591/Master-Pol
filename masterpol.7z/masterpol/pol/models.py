from django.db import models

# Тип компании
class Type_partner(models.Model):
    title = models.CharField(max_length=10, verbose_name="Название")

    def __str__(self):
        return self.title


# Регион
class Region(models.Model):
    title = models.CharField(max_length=200, verbose_name="Название")

    def __str__(self):
        return self.title


# Населенный пункт
class Locality(models.Model):
    title = models.CharField(max_length=200, verbose_name="Название")

    def __str__(self):
        return self.title


# Улица
class Street(models.Model):
    title = models.CharField(max_length=200, verbose_name="Название")

    def __str__(self):
        return self.title


# Адрес компании
class Address(models.Model):
    index = models.IntegerField(verbose_name="Индекс")
    region = models.ForeignKey(Region, on_delete=models.CASCADE, verbose_name="Регион")
    locality = models.ForeignKey(Locality, on_delete=models.CASCADE, verbose_name="Населенный пункт")
    street = models.ForeignKey(Street, on_delete=models.CASCADE, verbose_name="Улица")
    house = models.IntegerField(verbose_name="Номер дома")

    def __str__(self):
        return f"{self.index}, {self.region}, {self.locality}"


# Директор компании
class Director(models.Model):
    last_name = models.CharField(max_length=100, verbose_name="Фамилия")
    first_name = models.CharField(max_length=100, verbose_name="Имя")
    patronymic = models.CharField(max_length=100, verbose_name="Отчество")

    def __str__(self):
        return f"{self.last_name} {self.first_name} {self.patronymic}"


# Партнеры
class Partners(models.Model):
    type = models.ForeignKey(Type_partner, on_delete=models.CASCADE, verbose_name="Тип")
    name = models.CharField(max_length=250, verbose_name="Наименование")
    director = models.ForeignKey(Director, on_delete=models.CASCADE, verbose_name="ФИО директора")
    email = models.EmailField(verbose_name="Электронная почта")
    phone = models.CharField(max_length=20, verbose_name="Телефон")
    address = models.ForeignKey(Address, on_delete=models.CASCADE, verbose_name="Адрес")
    inn = models.CharField(max_length=20, verbose_name="ИНН")
    rating = models.IntegerField(verbose_name="Рейтинг")

    def __str__(self):
        return self.name


# Тип продукции
class Type_products(models.Model):
    type = models.CharField(max_length=50, verbose_name="Тип продукции")
    coefficient_type = models.FloatField(verbose_name="Коэффициент типа продукции")

    def __str__(self):
        return self.type


# Продукция
class Products(models.Model):
    type = models.ForeignKey(Type_products, on_delete=models.CASCADE, verbose_name="Тип продукции")
    name = models.CharField(max_length=300, verbose_name="Наименование")
    article = models.CharField(max_length=7, verbose_name="Артикул")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Минимальная стоимость")

    def __str__(self):
        return self.name


# Продажа
class Sale(models.Model):
    products = models.ForeignKey(Products, on_delete=models.CASCADE, verbose_name="Продукция")
    partner = models.ForeignKey(Partners, on_delete=models.CASCADE, verbose_name="Партнер")
    amount_products = models.IntegerField(verbose_name="Кол-во продукции")
    date_sale = models.DateField(verbose_name="Дата продажи")

    def __str__(self):
        return f"{self.products} - {self.partner}"


# Тип материала
class Type_material(models.Model):
    type = models.CharField(max_length=50, verbose_name="Тип")
    brak = models.FloatField(verbose_name="Процент брака")

    def __str__(self):
        return self.type